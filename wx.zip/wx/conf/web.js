/**
* Server configuration
*/

var conf = {
  dev_port: 80,
  test_port: 8222,
  sql:{
    host: "localhost",
    port: 8080,
    part: "daka-starter/daka",
    URL_USERSAVE: function(){
      return "http://"+this.host+":"+this.port+"/"+this.part+"/user/save";
    },
    URL_USERGET: function(openid){
      return "http://"+this.host+":"+this.port+"/"+this.part+"/user/get?userId=" + openid;
    }
  },
  URL_USERSESSION: function(){
    return "http://locahost:8080/wxauth/daka/session";
  }
}

module.exports = conf;
