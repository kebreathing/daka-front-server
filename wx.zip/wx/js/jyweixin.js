/* for weixin */
// wx.config({
//   debug: true,
//   appId: 'wx3e190bdc565a5c36',
//
// })
