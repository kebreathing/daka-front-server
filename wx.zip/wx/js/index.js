/**
* Js for index.html
*/
console.log(<%=openid%>)
